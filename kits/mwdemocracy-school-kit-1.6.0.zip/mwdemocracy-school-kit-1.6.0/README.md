# MWDemocracy 1.6.0: school install kit

Everything needed to run MWDemocracy on your own server. The program itself is
a signed, prebuilt image (`deploy/IMAGE`); this kit contains no source code.

## Install (Ubuntu or Debian server, 2 vCPU / 4 GB RAM recommended)

1. Point your web address (for example `vote.yourschool.edu.ph`) at the server
   with a DNS "A" record.
2. Copy this folder to the server (for example to `/opt/mwdemocracy`), then:

   ```bash
   cd /opt/mwdemocracy
   sudo ./deploy/install.sh --license /path/to/license.txt
   ```

   It asks for the web address and the first officer's email, checks the
   server, and sets everything up (HTTPS, restricted database account,
   backups, updates). It prints a temporary officer password at the end.

3. Open `https://<your-address>/admin/`, sign in, change the password, turn on
   two-factor sign-in, and follow the Setup wizard.

## Everyday tasks

```
./mwd doctor     check everything and say what to fix
./mwd backup     back up now (backups also run every night)
./mwd help       all commands
```

Updates appear on the officers' dashboard ("Update available"); an officer
approves, and the server installs it between elections with a backup and
automatic rollback. See `docs/updates.md`.

Running the election: `docs/election-guide.md`. Security design: `docs/security.md`.
