#!/usr/bin/env bash
# Daily backup of the MWDemocracy database and uploaded files.
# Run from the project folder, or install as a cron job (see readme):
#   0 2 * * *  cd /opt/MWDemocracy && ./deploy/backup.sh >> backups/backup.log 2>&1
#
# Optional, in .env:
#   BACKUP_PASSPHRASE=...   encrypt every backup (gpg, AES-256). Keep the passphrase
#                           somewhere safe OFF the server: without it backups can't be restored.
#   OFFSITE_REMOTE=...      also copy backups to cloud storage with rclone, e.g.
#                           "b2:school-backups/mwd" or "gdrive:MWDemocracy" (run `rclone config` once).
#   KEEP_DAYS=30            how long to keep backups (here and off-site).
set -euo pipefail
cd "$(dirname "$0")/.."

# Read one value from .env without executing the file.
envval() { [ -f .env ] && grep -E "^$1=" .env | tail -1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' || true; }
KEEP_DAYS="${KEEP_DAYS:-$(envval KEEP_DAYS)}"; KEEP_DAYS="${KEEP_DAYS:-30}"
BACKUP_PASSPHRASE="${BACKUP_PASSPHRASE:-$(envval BACKUP_PASSPHRASE)}"
OFFSITE_REMOTE="${OFFSITE_REMOTE:-$(envval OFFSITE_REMOTE)}"
DEST="${BACKUP_DIR:-./backups}"
STAMP="$(date +%F-%H%M)"
mkdir -p "$DEST"
umask 077

fail() { echo "$(date) BACKUP FAILED: $*" >&2; exit 1; }

DB="$DEST/db-$STAMP.sql.gz"
UP="$DEST/uploads-$STAMP.tar.gz"
docker compose exec -T db pg_dump -U mwd --clean --if-exists mwdemocracy | gzip > "$DB"
docker compose exec -T app tar -C /app/data -cz uploads > "$UP" 2>/dev/null || rm -f "$UP"

# Refuse to keep an empty dump (a failed backup must be noticed, not rotated in).
if [ "$(gzip -dc "$DB" | head -c 1000 | wc -c)" -lt 100 ]; then
  rm -f "$DB"
  fail "database dump is empty"
fi

FILES=("$DB")
[ -f "$UP" ] && FILES+=("$UP")

if [ -n "$BACKUP_PASSPHRASE" ]; then
  command -v gpg >/dev/null || fail "BACKUP_PASSPHRASE is set but gpg is not installed (apt install gnupg)"
  ENC=()
  for f in "${FILES[@]}"; do
    printf '%s' "$BACKUP_PASSPHRASE" | gpg --batch --yes --quiet --pinentry-mode loopback --passphrase-fd 0 \
      --symmetric --cipher-algo AES256 --s2k-digest-algo SHA512 --s2k-count 65011712 -o "$f.gpg" "$f"
    # Prove the encrypted copy opens before deleting the plain one.
    printf '%s' "$BACKUP_PASSPHRASE" | gpg --batch --quiet --pinentry-mode loopback --passphrase-fd 0 -d "$f.gpg" | gzip -t \
      || fail "could not verify the encrypted copy of $f"
    rm -f "$f"
    ENC+=("$f.gpg")
  done
  FILES=("${ENC[@]}")
fi

( cd "$DEST" && sha256sum "${FILES[@]##*/}" > "checksums-$STAMP.sha256" )
FILES+=("$DEST/checksums-$STAMP.sha256")

if [ -n "$OFFSITE_REMOTE" ]; then
  command -v rclone >/dev/null || fail "OFFSITE_REMOTE is set but rclone is not installed (curl https://rclone.org/install.sh | sudo bash)"
  for f in "${FILES[@]}"; do
    rclone copy --immutable "$f" "$OFFSITE_REMOTE/" || fail "off-site copy of $f to $OFFSITE_REMOTE failed"
  done
  rclone delete --min-age "${KEEP_DAYS}d" "$OFFSITE_REMOTE/" 2>/dev/null || true
  echo "$(date) copied off-site to $OFFSITE_REMOTE"
fi

find "$DEST" \( -name 'db-*.sql.gz*' -o -name 'uploads-*.tar.gz*' -o -name 'checksums-*.sha256' \) -mtime +"$KEEP_DAYS" -delete
echo "$(date) backup ok: ${FILES[0]}${BACKUP_PASSPHRASE:+ (encrypted)}"
