#!/usr/bin/env bash
# One-command installer for a fresh Ubuntu/Debian server.
#
#   sudo ./deploy/install.sh                                   # asks what it needs
#   sudo ./deploy/install.sh vote.yourschool.edu.ph officer@yourschool.edu.ph [--license license.txt]
#
# It checks the server first (size, ports, DNS), installs Docker if needed,
# writes .env with random secrets, starts everything with automatic HTTPS,
# gives the app a restricted database account, creates the first officer,
# and schedules nightly backups, backup checks and approved updates.
# Safe to run again: it keeps existing secrets and accounts.
set -euo pipefail
cd "$(dirname "$0")/.."

bold() { printf '\033[1m%s\033[0m\n' "$*"; }
ok() { printf '  \033[32m✓\033[0m %s\n' "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }
die() { printf '\033[31mError:\033[0m %s\n' "$*" >&2; exit 1; }

DOMAIN="" EMAIL="" LICENSE=""
while [ $# -gt 0 ]; do
  case "$1" in
    --license) LICENSE="${2:-}"; shift 2 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) if [ -z "$DOMAIN" ]; then DOMAIN="$1"; elif [ -z "$EMAIL" ]; then EMAIL="$1"; fi; shift ;;
  esac
done

[ "$(id -u)" -eq 0 ] || die "run it with sudo:  sudo ./deploy/install.sh"

envval() { [ -f .env ] && grep -E "^$1=" .env | tail -1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' || true; }
[ -n "$DOMAIN" ] || DOMAIN="$(envval DOMAIN)"
if [ -z "$DOMAIN" ]; then read -rp "Web address for the election site (e.g. vote.yourschool.edu.ph): " DOMAIN; fi
[[ "$DOMAIN" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,}$ ]] || die "\"$DOMAIN\" doesn't look like a web address (example: vote.yourschool.edu.ph)"
ADMIN_EXISTS=""
if [ -z "$EMAIL" ] && [ ! -f .env ]; then read -rp "Email of the first election officer (the adviser): " EMAIL; fi
[ -z "$EMAIL" ] || [[ "$EMAIL" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]] || die "\"$EMAIL\" doesn't look like an email address"

bold "1/6  Checking this server"
CPUS="$(nproc)"; MEM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"; DISK_GB="$(df -Pk . | awk 'NR==2 {print int($4/1048576)}')"
[ "$CPUS" -ge 2 ] && ok "$CPUS CPU cores" || warn "$CPUS CPU core (2 or more recommended: sign-in rushes will be slower)"
[ "$MEM_MB" -ge 3500 ] && ok "$((MEM_MB / 1024)) GB memory" || warn "$MEM_MB MB memory (4 GB recommended)"
[ "$DISK_GB" -ge 10 ] && ok "$DISK_GB GB free disk" || warn "only $DISK_GB GB free disk (10 GB or more recommended)"
# Building the server needs more memory than running it: add swap on small machines.
if [ "$MEM_MB" -lt 3000 ] && [ "$(awk '/SwapTotal/ {print $2}' /proc/meminfo)" -eq 0 ] && [ ! -f /swapfile ]; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap -q /swapfile && swapon /swapfile && echo '/swapfile none swap sw 0 0' >> /etc/fstab \
    && ok "added 2 GB of swap (small server: needed while building)" || warn "could not add swap; the build may run out of memory"
fi
for port in 80 443; do
  if ss -ltnH "sport = :$port" 2>/dev/null | grep -q . && ! docker ps --format '{{.Ports}}' 2>/dev/null | grep -q ":$port->"; then
    warn "port $port is already used by another program (a web server?). Stop it, or HTTPS can't start."
  fi
done
RESOLVED="$(getent ahostsv4 "$DOMAIN" 2>/dev/null | awk '{print $1}' | sort -u | tr '\n' ' ')"
LOCAL_IPS="$(hostname -I 2>/dev/null || true)"
if [ -z "$RESOLVED" ]; then
  warn "$DOMAIN doesn't resolve yet. Create a DNS \"A\" record pointing to this server; HTTPS starts working once it does."
elif printf '%s' " $LOCAL_IPS " | grep -qwF "${RESOLVED%% *}"; then
  ok "$DOMAIN points to this server ($RESOLVED)"
else
  warn "$DOMAIN points to $RESOLVED; this server's addresses are: $LOCAL_IPS(fine if your provider uses a separate public IP)"
fi
if command -v ufw >/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow 80/tcp >/dev/null && ufw allow 443/tcp >/dev/null && ok "firewall: opened ports 80 and 443"
fi

bold "2/6  Docker"
if ! command -v docker >/dev/null; then
  echo "  Installing Docker…"; curl -fsSL https://get.docker.com | sh >/dev/null
fi
docker compose version >/dev/null 2>&1 || die "Docker Compose is missing; install the docker-compose-plugin package"
ok "$(docker --version | cut -d, -f1)"

bold "3/6  Settings and license"
if [ ! -f .env ]; then
  rand() { openssl rand -base64 64 | tr -d '/+=\n' | head -c "$1"; }
  umask 077
  cat > .env <<ENV
DOMAIN=$DOMAIN
POSTGRES_PASSWORD=$(rand 40)
SESSION_SECRET=$(rand 64)
ENV
  ok "wrote .env with random secrets (keep a copy somewhere safe, off this server)"
else
  ok ".env already exists; keeping its secrets"
  ADMIN_EXISTS=1
fi
if [ -n "$LICENSE" ]; then
  [ -f "$LICENSE" ] || die "license file $LICENSE not found"
  install -m 644 "$LICENSE" branding/license.txt && ok "license installed"
fi
[ -f branding/license.txt ] && ok "license file present" || warn "no license file: runs as an evaluation copy (50 voters). Add it later with:  ./mwd license <file>"

mkdir -p backups && chown 10001:10001 backups
if [ -d backend ]; then
  # Source checkout (the vendor's repository): build the image here.
  bold "4/6  Building and starting (the first build takes 5–15 minutes)"
  GIT_COMMIT="$(git rev-parse --short=12 HEAD 2>/dev/null || true)" docker compose up -d --build --quiet-pull 2>&1 | grep -vE "^\s*$" | tail -3 || true
else
  # School install kit: pull the signed, prebuilt image named in deploy/IMAGE.
  bold "4/6  Downloading and starting"
  IMAGE="$(tr -d '[:space:]' < deploy/IMAGE 2>/dev/null || true)"
  [[ "$IMAGE" =~ ^[A-Za-z0-9./_:-]+@sha256:[0-9a-f]{64}$ ]] || die "deploy/IMAGE is missing or not pinned by digest; download the kit again"
  if ! docker image inspect mwdemocracy:latest >/dev/null 2>&1 || [ "$(docker image inspect --format '{{index .RepoDigests 0}}' mwdemocracy:latest 2>/dev/null)" != "$IMAGE" ]; then
    docker pull -q "$IMAGE" >/dev/null || die "could not download $IMAGE (check the internet connection)"
    docker tag "$IMAGE" mwdemocracy:latest
  fi
  ok "image $(printf '%s' "$IMAGE" | sed 's/@sha256:\(.\{12\}\).*/@sha256:\1…/')"
  docker compose up -d --quiet-pull 2>&1 | grep -vE "^\s*$" | tail -3 || true
fi
for _ in $(seq 1 90); do
  docker compose exec -T app curl -fsS http://localhost:8080/api/health >/dev/null 2>&1 && break
  sleep 2
done
docker compose exec -T app curl -fsS http://localhost:8080/api/health >/dev/null 2>&1 || die "the app didn't start; see:  docker compose logs app"
ok "running"
docker compose exec -T app mwdemocracy verify >/dev/null && ok "website files match the build" || warn "web files do not match the build (run: docker compose exec app mwdemocracy verify)"

bold "5/6  Security"
chmod +x deploy/*.sh mwd
./deploy/harden-db.sh >/dev/null && docker compose up -d app >/dev/null 2>&1 && ok "the app uses a restricted database account (can't edit or delete votes)"
for _ in $(seq 1 60); do docker compose exec -T app curl -fsS http://localhost:8080/api/health >/dev/null 2>&1 && break; sleep 2; done
PASS=""
if [ -n "$EMAIL" ] && [ -z "$ADMIN_EXISTS" ]; then
  PASS="$(openssl rand -base64 18 | tr -d '/+=')"
  docker compose exec -T -e ADMIN_PASSWORD="$PASS" app mwdemocracy create-admin --email "$EMAIL" --name "Election Officer" >/dev/null
  ok "officer account created for $EMAIL"
fi

bold "6/6  Scheduled jobs"
CRON="0 2 * * * cd $(pwd) && ./deploy/backup.sh >> $(pwd)/backups/backup.log 2>&1"
VERIFY="30 2 * * * cd $(pwd) && ./deploy/verify-backup.sh >> $(pwd)/backups/verify.log 2>&1"
UPDATE="*/5 * * * * cd $(pwd) && ./deploy/update.sh >> $(pwd)/backups/update.log 2>&1"
( crontab -l 2>/dev/null | grep -v 'deploy/backup.sh' | grep -v 'deploy/verify-backup.sh' | grep -v 'deploy/update.sh'; echo "$CRON"; echo "$VERIFY"; echo "$UPDATE" ) | crontab -
ok "nightly backup (2:00), backup check (2:30), approved updates (every 5 minutes)"

echo
bold "Done. Open https://$DOMAIN/admin/"
if [ -n "$PASS" ]; then
  echo "  Officer email:       $EMAIL"
  echo "  Temporary password:  $PASS"
  echo "  Sign in, change the password, and turn on two-factor sign-in (Officers & security)."
fi
echo "  Then follow the Setup wizard. Day-to-day commands:  ./mwd help"
echo "  Strongly recommended: set BACKUP_PASSPHRASE and OFFSITE_REMOTE in .env (see readme, Operations)."
