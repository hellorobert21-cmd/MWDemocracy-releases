#!/usr/bin/env bash
# Restores the database (and optionally uploaded files) from a backup made by
# deploy/backup.sh or the console's "vps backup". REPLACES the current data.
#
#   ./deploy/restore.sh backups/db-2026-11-03-0200.sql.gz.gpg [backups/uploads-2026-11-03-0200.tar.gz.gpg]
#
# Encrypted (.gpg) backups need BACKUP_PASSPHRASE in .env or the environment,
# or gpg asks for it. The app is stopped during the restore and started again after.
set -euo pipefail
cd "$(dirname "$0")/.."

DB_FILE="${1:-}"
UP_FILE="${2:-}"
[ -n "$DB_FILE" ] && [ -f "$DB_FILE" ] || { echo "Usage: $0 <db-backup.sql.gz[.gpg]> [uploads-backup.tar.gz[.gpg]]" >&2; exit 2; }
[ -z "$UP_FILE" ] || [ -f "$UP_FILE" ] || { echo "No such file: $UP_FILE" >&2; exit 2; }

envval() { [ -f .env ] && grep -E "^$1=" .env | tail -1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' || true; }
BACKUP_PASSPHRASE="${BACKUP_PASSPHRASE:-$(envval BACKUP_PASSPHRASE)}"

# Writes the plain (gzip) content of a backup file to stdout.
plain() {
  case "$1" in
    *.gpg)
      if [ -n "$BACKUP_PASSPHRASE" ]; then
        printf '%s' "$BACKUP_PASSPHRASE" | gpg --batch --quiet --pinentry-mode loopback --passphrase-fd 0 -d "$1"
      else
        gpg --quiet -d "$1"
      fi ;;
    *) cat "$1" ;;
  esac
}

# Check the files are readable BEFORE touching anything.
echo "Checking $DB_FILE …"
plain "$DB_FILE" | gzip -t || { echo "The database backup is damaged or the passphrase is wrong. Nothing was changed." >&2; exit 1; }
[ -z "$UP_FILE" ] || plain "$UP_FILE" | gzip -t || { echo "The uploads backup is damaged. Nothing was changed." >&2; exit 1; }
SUM="$(dirname "$DB_FILE")/checksums-$(basename "$DB_FILE" | sed -E 's/^db-(.*)\.sql\.gz(\.gpg)?$/\1/').sha256"
if [ -f "$SUM" ]; then
  ( cd "$(dirname "$DB_FILE")" && grep -F "$(basename "$DB_FILE")" "$(basename "$SUM")" | sha256sum -c --quiet ) \
    || { echo "Checksum mismatch: the backup file was changed after it was made. Nothing was changed." >&2; exit 1; }
  echo "Checksum OK."
fi

echo
echo "This REPLACES every election, voter, ballot and setting on this server with the backup:"
echo "  $DB_FILE${UP_FILE:+ and $UP_FILE}"
echo "Ballots cast since that backup will be lost. Take a fresh backup first if unsure (./deploy/backup.sh)."
read -r -p 'Type RESTORE to continue: ' answer
[ "$answer" = "RESTORE" ] || { echo "Cancelled."; exit 1; }

docker compose stop app
trap 'docker compose start app >/dev/null' EXIT
plain "$DB_FILE" | gunzip | docker compose exec -T db psql -q -v ON_ERROR_STOP=1 -U mwd -d mwdemocracy >/dev/null
echo "Database restored."
if [ -n "$UP_FILE" ]; then
  docker compose run --rm --no-deps -T --entrypoint sh app -c 'rm -rf /app/data/uploads && mkdir -p /app/data && tar -C /app/data -xz' < <(plain "$UP_FILE")
  echo "Uploaded files restored."
fi
trap - EXIT
docker compose start app
echo "Done. Officers should sign in again and check the dashboard."
