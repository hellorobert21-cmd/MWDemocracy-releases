#!/usr/bin/env bash
# Proves the newest backup can actually be restored: loads it into a throwaway
# database next to the real one, checks the main tables and the audit-log
# chain, then deletes the copy. The live data is never touched.
#
#   ./deploy/verify-backup.sh                     # newest backup in ./backups
#   ./deploy/verify-backup.sh backups/db-….sql.gz.gpg
#
# Run it after the nightly backup (see readme):
#   30 2 * * *  cd /opt/MWDemocracy && ./deploy/verify-backup.sh >> backups/verify.log 2>&1
# Encrypted backups need BACKUP_PASSPHRASE in .env (as for restore.sh).
set -euo pipefail
cd "$(dirname "$0")/.."

envval() { [ -f .env ] && grep -E "^$1=" .env | tail -1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' || true; }
BACKUP_PASSPHRASE="${BACKUP_PASSPHRASE:-$(envval BACKUP_PASSPHRASE)}"
DEST="${BACKUP_DIR:-./backups}"
FILE="${1:-$(ls -t "$DEST"/db-*.sql.gz "$DEST"/db-*.sql.gz.gpg 2>/dev/null | head -1 || true)}"
CHECK_DB="mwd_restore_check"

fail() { echo "$(date) BACKUP CHECK FAILED: $*" >&2; exit 1; }
[ -n "$FILE" ] && [ -f "$FILE" ] || fail "no backup found in $DEST"

plain() {
  case "$1" in
    *.gpg)
      [ -n "$BACKUP_PASSPHRASE" ] || fail "$1 is encrypted; set BACKUP_PASSPHRASE in .env"
      printf '%s' "$BACKUP_PASSPHRASE" | gpg --batch --quiet --pinentry-mode loopback --passphrase-fd 0 -d "$1" ;;
    *) cat "$1" ;;
  esac
}
psql_db() { docker compose exec -T db psql -v ON_ERROR_STOP=1 -q -At -U mwd "$@"; }

cleanup() { psql_db -d mwdemocracy -c "DROP DATABASE IF EXISTS $CHECK_DB" >/dev/null 2>&1 || true; }
trap cleanup EXIT
cleanup
psql_db -d mwdemocracy -c "CREATE DATABASE $CHECK_DB" >/dev/null || fail "could not create the check database"

plain "$FILE" | gzip -dc | psql_db -d "$CHECK_DB" >/dev/null 2>"$DEST/verify-last-errors.txt" \
  || fail "$FILE did not restore cleanly (see $DEST/verify-last-errors.txt)"

COUNTS="$(psql_db -d "$CHECK_DB" -c "SELECT (SELECT count(*) FROM elections) || ' elections, ' ||
  (SELECT count(*) FROM voters) || ' voters, ' || (SELECT count(*) FROM ballots) || ' online ballots, ' ||
  (SELECT count(*) FROM audit_logs) || ' audit entries'")" || fail "restored copy is missing tables"

# The audit chain must be intact in the copy too (same check as the app's).
BROKEN="$(psql_db -d "$CHECK_DB" -c "SELECT id FROM (
    SELECT id, hash, prev_hash, lag(hash) OVER (ORDER BY id) AS real_prev,
      encode(sha256(convert_to(concat_ws('|', coalesce(prev_hash, ''), actor, action, details::text,
        coalesce(ip, ''), (extract(epoch FROM created_at) * 1000000)::bigint), 'UTF8')), 'hex') AS calc
    FROM audit_logs WHERE hash IS NOT NULL) x
  WHERE calc <> hash OR prev_hash IS DISTINCT FROM real_prev ORDER BY id LIMIT 1" 2>/dev/null || true)"
[ -z "$BROKEN" ] || fail "audit log chain in $FILE is broken at entry #$BROKEN"

rm -f "$DEST/verify-last-errors.txt"
echo "$(date) backup check ok: $(basename "$FILE") restores ($COUNTS)"
