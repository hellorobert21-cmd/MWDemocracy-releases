#!/usr/bin/env bash
# Installs an MWDemocracy update that the officers approved on the dashboard
# (Overview → Software update → Install), or a signed release file you give it.
#
#   ./deploy/update.sh                     # install the approved update, if any (safe to run from cron)
#   ./deploy/update.sh --file latest.txt   # install a signed release file (offline schools)
#   ./deploy/update.sh --status            # show what is waiting
#
# Cron (the installer adds this): every 5 minutes, does nothing unless an update was approved.
#   */5 * * * *  cd /opt/MWDemocracy && ./deploy/update.sh >> backups/update.log 2>&1
#
# What it does, in order. Any failure stops it and puts the old version back:
#   1. checks the release file's signature with the key built into the RUNNING version
#   2. refuses while an election is open or voting is paused
#   3. backs up the database (deploy/backup.sh)
#   4. installs: pulls the digest-pinned image, or builds the signed git commit
#   5. starts it, waits for the health check, confirms the version and web-file check
#   6. on any failure: the previous version is restored automatically
set -euo pipefail
cd "$(dirname "$0")/.."

LOCK="${TMPDIR:-/tmp}/mwdemocracy-update.lock"
exec 9>"$LOCK"
flock -n 9 || { echo "$(date) another update is running"; exit 0; }

MODE=approved FILE=""
case "${1:-}" in
  --file) MODE=file FILE="${2:?usage: $0 --file <release.txt>}" ;;
  --status) MODE=status ;;
  "") ;;
  *) echo "usage: $0 [--file release.txt | --status]" >&2; exit 2 ;;
esac

app() { docker compose exec -T app "$@"; }
log() { echo "$(date) $*"; }
result() {  # result <ok|failed|waiting> <message>
  local msg="${2//\"/\'}"
  printf '{"state":"%s","message":"%s","version":"%s","at":"%s"}\n' "$1" "$msg" "${VERSION:-}" "$(date -u +%FT%TZ)" \
    | app sh -c 'mkdir -p /app/data/update && cat > /app/data/update/result.json' 2>/dev/null || true
  log "$1: $2"
}

# ---------- 1. the release file ----------
if [ "$MODE" = file ]; then
  [ -f "$FILE" ] || { echo "No such file: $FILE" >&2; exit 2; }
  SIGNED="$(cat "$FILE")"
else
  SIGNED="$(app cat /app/data/update/request.txt 2>/dev/null || true)"
  if [ -z "$SIGNED" ]; then
    [ "$MODE" = status ] && echo "No update is waiting for installation."
    exit 0
  fi
fi

VERSION="" COMMIT="" IMAGE=""
FIELDS="$(printf '%s\n' "$SIGNED" | app mwdemocracy release verify --env -)" || { result failed "The release file's signature is not valid. Nothing was changed."; exit 1; }
while IFS='=' read -r k v; do
  case "$k" in
    VERSION) [[ "$v" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] && VERSION="$v" ;;
    COMMIT) [[ "$v" =~ ^[0-9a-f]{7,64}$ ]] && COMMIT="$v" ;;
    IMAGE) [[ -z "$v" || "$v" =~ ^[A-Za-z0-9./_:-]+@sha256:[0-9a-f]{64}$ ]] && IMAGE="$v" ;;
  esac
done <<< "$FIELDS"
[ -n "$VERSION" ] && [ -n "$COMMIT" ] || { result failed "The release file is incomplete. Nothing was changed."; exit 1; }
CURRENT="$(app curl -fsS "http://localhost:8080/api/version" 2>/dev/null | sed -n 's/.*"version":"\([^"]*\)".*/\1/p' || true)"
[ -n "$CURRENT" ] || CURRENT="$(app mwdemocracy --version | awk '{print $2}')"

if [ "$MODE" = status ]; then
  echo "Approved: MWDemocracy $VERSION (commit ${COMMIT:0:12}${IMAGE:+, image $IMAGE}); running $CURRENT."
  app mwdemocracy update-ready || true
  exit 0
fi

# ---------- 2. never during voting ----------
if ! WHY="$(app mwdemocracy update-ready 2>&1)"; then
  result waiting "Waiting: ${WHY##*Error: }"
  exit 0
fi

log "installing MWDemocracy $VERSION (running $CURRENT)"
result waiting "Installing $VERSION: backing up first…"

# ---------- 3. backup ----------
./deploy/backup.sh || { result failed "The backup before the update failed, so the update was not installed."; exit 1; }

# ---------- 4. install, keeping the old version to fall back on ----------
OLD_GIT="$(git rev-parse HEAD 2>/dev/null || true)"
docker image inspect mwdemocracy:latest >/dev/null 2>&1 && docker tag mwdemocracy:latest mwdemocracy:rollback

rollback() {
  log "rolling back to $CURRENT"
  if [ -n "$OLD_GIT" ] && [ -z "$IMAGE" ]; then git -c advice.detachedHead=false checkout -q "$OLD_GIT" || true; fi
  docker image inspect mwdemocracy:rollback >/dev/null 2>&1 && docker tag mwdemocracy:rollback mwdemocracy:latest
  docker compose up -d app >/dev/null 2>&1 || true
  for _ in $(seq 1 60); do app curl -fsS http://localhost:8080/api/health >/dev/null 2>&1 && break; sleep 2; done
  result failed "Installing $VERSION failed ($1). The previous version $CURRENT was put back; your data is unchanged and a backup was taken."
  exit 1
}

if [ -z "$IMAGE" ] && [ ! -d .git ]; then
  result failed "Release $VERSION has no prebuilt image, and this server installs from images. Nothing was changed."
  exit 1
fi
if [ -n "$IMAGE" ]; then
  docker pull "$IMAGE" || rollback "could not download the image"
  docker tag "$IMAGE" mwdemocracy:latest
else
  git fetch -q --tags origin || rollback "could not download the source"
  git cat-file -e "$COMMIT^{commit}" 2>/dev/null || rollback "commit $COMMIT is not in the repository"
  git -c advice.detachedHead=false checkout -q --detach "$COMMIT" || rollback "could not check out $COMMIT"
  GIT_COMMIT="${COMMIT:0:12}" docker compose build -q app || rollback "the build failed"
fi

# ---------- 5. start and check ----------
docker compose up -d app || rollback "the new version did not start"
HEALTHY=""
for _ in $(seq 1 60); do
  if app curl -fsS http://localhost:8080/api/health >/dev/null 2>&1; then HEALTHY=1; break; fi
  sleep 2
done
[ -n "$HEALTHY" ] || rollback "the health check did not pass within 2 minutes"
RUNNING="$(app curl -fsS http://localhost:8080/api/version | sed -n 's/.*"version":"\([^"]*\)".*/\1/p')"
[ "$RUNNING" = "$VERSION" ] || rollback "it reports version '$RUNNING' instead of $VERSION"
app mwdemocracy verify >/dev/null || rollback "the web-file check failed"

app rm -f /app/data/update/request.txt || true
result ok "MWDemocracy $VERSION is installed (was $CURRENT). A backup was taken just before."
