#!/usr/bin/env bash
# Gives the app its own restricted database account (run once; safe to re-run,
# and after updates).
#
# By default the app connects as the database owner, a superuser in the
# official Postgres image. After this script the app connects as `mwd_app`,
# which:
#   - can read and add ballots, ballot choices, audit entries and seals, but
#     can't edit or delete them (and can't switch off their protections);
#   - can't change the schema, run programs on the database server or read files;
#   - is used for everything except schema changes (those run as the owner
#     through MIGRATE_DATABASE_URL at start-up).
#
#   ./deploy/harden-db.sh
set -euo pipefail
cd "$(dirname "$0")/.."

envval() { [ -f .env ] && grep -E "^$1=" .env | tail -1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' || true; }
PW="$(envval DB_APP_PASSWORD)"
if [ -z "$PW" ]; then
  PW="$(openssl rand -hex 24)"
  printf '\n# Restricted database account for the app (deploy/harden-db.sh)\nDB_APP_USER=mwd_app\nDB_APP_PASSWORD=%s\n' "$PW" >> .env
  echo "Added DB_APP_USER and DB_APP_PASSWORD to .env"
fi

{
  cat <<'SQL'
SELECT format(CASE WHEN EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mwd_app')
                   THEN 'ALTER ROLE mwd_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD %L'
                   ELSE 'CREATE ROLE mwd_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD %L' END, :'pw') \gexec
SQL
  cat deploy/db-roles.sql
} | docker compose exec -T db psql -v ON_ERROR_STOP=1 -q -U mwd -d mwdemocracy -v pw="$PW"
echo "Restricted account ready. Restart the app to use it:  docker compose up -d app"
