-- Privileges of the restricted app account (applied by deploy/harden-db.sh,
-- run as the database owner). Re-running it is safe.
GRANT CONNECT ON DATABASE mwdemocracy TO mwd_app;
GRANT USAGE ON SCHEMA public TO mwd_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO mwd_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO mwd_app;
-- Votes, the audit log and ballot seals: add and read only.
REVOKE UPDATE, DELETE, TRUNCATE ON ballots, ballot_choices, audit_logs, election_seals FROM mwd_app;
-- The migration history belongs to the owner.
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON _sqlx_migrations FROM mwd_app;
-- Tables added by later versions get the ordinary privileges automatically
-- (re-run harden-db.sh after an update to apply any new restrictions).
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO mwd_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO mwd_app;
