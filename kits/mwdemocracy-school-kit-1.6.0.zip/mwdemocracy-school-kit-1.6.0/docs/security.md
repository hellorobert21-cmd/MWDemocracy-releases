# Security design

How MWDemocracy protects an election, mapped to the practices US election
offices follow (federal voting-system standards VVSG 2.0, CISA election
security guidance, NIST controls). It is a **school** election system:
these are the same ideas, sized for a school.

## Practices and how they're applied

| US practice | In MWDemocracy |
|---|---|
| **Auditability / software independence**: a result must be checkable without trusting the software | Paper fallback counted with Scan & Count (paper is the record); **ballot seal** taken at closing (SHA-256 over every online ballot), written to the audit log and printed on the certificate. Any later change, removal or addition shows as "CHANGED SINCE CLOSING" |
| **Canvass / reconciliation** | Certificate checks *students recorded as voting online = online ballots*; paper: printed = counted + spoiled + unused, and never more ballots than paper voters |
| **Post-election audit** (risk-limiting audits) | "Pick ballots to hand-check": random sample of scanned paper ballots for watchers |
| **Least privilege** | Roles: admin / observer / moderator. Moderators (student volunteers) see only Q&A, never the voter list or results. The app uses a **restricted database account** (`deploy/harden-db.sh`): it can add and read votes and audit entries but can't edit or delete them, switch off their protections, change the schema or run programs on the database server |
| **Two-person rule / chain of custody** | Two-officer approval for opening/closing voting, deleting elections, officer changes, weakening security, removing a counted paper ballot, entering paper totals, installing updates |
| **Tamper-evident logging** | Audit log is append-only (database trigger) and **hash-chained**: each entry carries a fingerprint of itself and the previous one; the Audit log page and certificate show whether the chain is intact |
| **Multi-factor authentication** | Officer 2FA (TOTP, RFC 6238), each code accepted once; secrets **encrypted at rest** |
| **Secure configuration / hardening** | App container: non-root, read-only filesystem, no Linux capabilities, no privilege escalation; web files read-only and fingerprinted at build time (changed files are not served) |
| **Patch management / supply chain** | Signed updates (Ed25519 release key), digest-pinned images, never installed while voting is open, automatic rollback; dependency audit (`cargo audit`) and end-to-end tests in CI |
| **Backups and recovery** | Encrypted (AES-256) off-site backups, nightly restore test including the audit chain |
| **Logic & accuracy testing** before each election | Practice election in [the election guide](election-guide.md); test kits in `deploy/scan-test/` and `deploy/tests/` |
| **Input/output handling** (stored cross-site scripting) | Every page builds HTML with auto-escaping `html` templates (CI-enforced), plus a strict Content Security Policy that blocks inline scripts as a second layer; uploads are checked by content, never by name |
| **Ballot secrecy** | Who voted and what was voted are stored separately; receipts confirm a ballot was counted without revealing choices; the help desk sees *whether* a student voted, never how |

## Cryptography

| Use | Algorithm | Notes |
|---|---|---|
| Passwords people choose (officers, candidates, self-registered students) | Argon2id, 46 MiB, 1 pass | OWASP's first recommended setting. Older hashes upgrade automatically at the next sign-in |
| Generated student passwords (~40 random bits) | Argon2id, 8 MiB, 1 pass | Lighter so a whole school can sign in quickly; safe because the passwords are random and sign-in is rate-limited |
| Unknown accounts | Same cost as a real one | No timing hint about which accounts exist |
| Session tokens | HMAC-SHA256 (JWT, algorithm pinned to HS256, expiry required) | Key derived from `SESSION_SECRET` with HKDF-SHA256, separate from every other key |
| Session cookie | `__Host-mwd_session`, HttpOnly, Secure, SameSite=Strict | The prefix stops other subdomains from planting a sign-in |
| 2FA secrets at rest | XChaCha20-Poly1305, random 24-byte nonce, officer id as associated data | Separate HKDF key; a stolen database alone doesn't reveal 2FA secrets |
| Random codes (receipts 60 bits, slip passwords 40 bits, ballot serials 50 bits) | OS random source, unbiased 32-symbol alphabet | Candidate edit links: 192 bits, stored only as SHA-256 |
| License and release files | Ed25519 (strict verification), domain-separated signatures | Signing keys stored encrypted: Argon2id (64 MiB, 3 passes) + ChaCha20-Poly1305 |
| Audit chain, ballot seal, results fingerprint, web-file fingerprints | SHA-256 | |
| Backups | GnuPG AES-256, SHA-512 key derivation (high iteration count) | |
| Transport | TLS 1.2/1.3 via Caddy, HSTS | |

**Changing `SESSION_SECRET`:** set the old value as `SESSION_SECRET_PREVIOUS`
and a new `SESSION_SECRET`, restart. Sign-ins and 2FA keep working; 2FA
secrets are re-encrypted with the new key as officers sign in. Remove
`SESSION_SECRET_PREVIOUS` after a session length (8 hours by default).

## What it does not protect against

- **Someone who controls the server** (root on the machine, or both the
  database owner account and `SESSION_SECRET`) could change online votes
  *before* closing. The ballot seal detects changes after closing; paper ballots
  and voting stations at school reduce the reliance on the server.
- **Shared or sold slips** and voting under pressure at home: use supervised
  voting periods and voting stations.
- **Flooding attacks** against a single server: put a CDN such as Cloudflare
  in front of it; the paper fallback keeps voting possible.
- It has **not been independently tested**. Before relying on it for a large
  election, have a university security group or a professional tester review
  it under a written scope.
