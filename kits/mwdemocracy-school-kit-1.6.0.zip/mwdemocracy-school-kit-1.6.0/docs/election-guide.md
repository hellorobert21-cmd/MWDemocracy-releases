# Running an election with MWDemocracy

A step-by-step guide for the COMELEC club and its adviser. You don't need to
know programming. Keep this guide with the club's records and pass it on to
next year's officers.

---

## Who does what

| Role | Who | Account |
|---|---|---|
| Admin | Club adviser (teacher) | Admin, with two-factor sign-in |
| Admin | COMELEC chair | Admin, with two-factor sign-in |
| Help desk | 2–4 club members per voting area | Admin accounts for the help desk, or Observer if they only look things up |
| Q&A moderators | 1–2 club members | Moderator |
| Watchers | Other teachers or advisers | Observer (can see everything, change nothing) |
| Technical contact | Whoever looks after the server | Admin while setting up, then Observer during voting |

Turn on **Two-officer approval** (Officers & security). Then opening or closing
voting, adding officers and entering paper counts all need **both** the adviser
and the chair.

---

## 4–6 weeks before

1. **Sign in** at `https://<your-site>/admin/` and run the **Setup wizard**
   (school name, logo, theme).
2. **Import the students:** Voters → Import CSV (LRN, name, grade, section).
   Print voter slips (Voters → Slips) and keep them locked away.
3. **Create the election:** Elections → New. Add the positions (President,
   Vice President…) and the candidates, or turn on **Candidate filing** so
   students apply online and you approve them.
4. **Set the calendar:** Elections → *your election* → Calendar. Add filing
   closes, campaign period, miting de avance, and so on. The home page shows
   these with a countdown.
5. **Candidate accounts:** give each candidate a login so they can add their
   photo, platform and video, and answer questions. You approve every change.
6. **Check the readiness list** on the Overview. Everything should be ✓.

## 1–2 weeks before

7. **Practice election:** create a test election for one section and let
   them vote. Practise:
   - the help desk: look up an LRN, reset a password, unlock a student
   - **Pause all voting** and **Resume**
   - posting an announcement
   - closing voting and printing the certificate
8. **Prepare the paper fallback:** Elections → *your election* → **Paper
   ballots**. Choose the paper (A4 or Long) and, if some positions are only for
   certain grades, the grade: each grade gets its own version, marked
   **GRADE 7**, **GRADE 8**… at the top. Print at 100%, keep each grade's pile
   separate and sealed with a ballot box. Every ballot has its own number and
   QR code, so it can be counted with **Scan & Count**. Ballots are never
   linked to a student. You'll only use them if the internet fails.
9. **Backups:** confirm the System health page shows a recent backup.
10. **Voting stations:** for students without phones, set up school laptops:
    Help desk → **Make this device a voting station**.

## Election day

11. **Open voting:** Elections → Open voting (the second admin approves it).
12. **Projector mode:** show live turnout and results in the hall.
13. **Help desk:** students who can't sign in come to you. You can see
    *whether* a student voted, never *who* they voted for.
14. **Announcements:** for example "Voting extended to 3 PM". These appear on
    every screen within 30 seconds.

### If something goes wrong

| Problem | What to do |
|---|---|
| A student forgot their password | Help desk → look up the LRN → **New password** → print a slip |
| "Too many attempts" | Help desk → **Unlock sign-in** |
| Something looks wrong (suspected cheating, a bug) | Overview → **Pause all voting**. Students keep their choices. Investigate, then **Resume**. |
| **Internet or Wi-Fi is down** | 1. Pause voting and post an announcement. 2. At the help desk, look up each student and press **Voting on paper**, *then* hand them ONE ballot of the grade it tells you (this stops them voting online too). Don't write down which ballot number went to whom. 3. Collect ballots in the sealed box. A student who spoils a ballot gets a new one; keep the spoiled one aside. |
| A security alert says website files changed | Pause voting and call the technical contact. Don't ignore it. |
| The site is slow during a sign-in rush | Normal for a minute; the sign-in page retries by itself. Let classes vote in turns next time. |

## After voting

15. **Close voting** (the second admin approves it).
16. **If paper ballots were used:** open the box with watchers present, mix the
    ballots, then Elections → **Scan & Count** on a phone or laptop with a
    camera (it works over the school's HTTPS address).
    - Hold each ballot flat in the frame. The scanner reads the number and
      marks and shows them on a copy of the ballot. **Yellow** rows are faint
      marks or ✓/✗: look at the paper and tap to decide. Then press **Count**.
    - A ballot that can't be read: **Type a ballot instead** (enter the number
      under the QR code and tap the choices).
    - Spoiled ballots: press **Spoiled** with that ballot's number.
    - The screen refuses duplicates (photocopies), ballots from another
      election or grade, and more ballots than students marked "voting on paper".
    - When done, press **Pick ballots to hand-check** and have the watchers
      compare those ballots with what was counted. The paper is the official
      record.
    - No camera? Count by hand and use **Paper totals (by hand)** instead (one
      method per election, not both).
17. **Certificate:** print it and have it signed by the chair, the adviser and
    the principal. Its fingerprint proves the counts weren't changed later.
18. **Winners list:** a one-page list of the new officers for the oath-taking.
19. **Results graphic:** a ready-made image for the school's Facebook page.
20. **Audit log:** Audit log → Print / save PDF, signed and kept with the
    certificate.
21. **Survey:** Elections → **Survey** shows how easy students found voting,
    useful for next year.
22. **Ties:** if a position is tied, use **Start runoff** or your election rules.

## Handing over to next year's club

- **Accounts:** remove officers who are leaving (Officers & security) and add
  the new adviser and chair. Never share one account between people.
- **License:** the Overview shows when it expires. Renew before the next
  school year; the new file takes effect without a restart.
- **Updates:** when the Overview shows **Update available**, install it
  *between* elections: press **Install** (the second admin approves). The
  server backs up, installs and checks itself within 5 minutes, and puts the
  old version back if anything goes wrong. It never installs while voting is
  open. A red **Security fix** should be installed soon.
- **Server:** write down where it's hosted, who pays for it, and who has the
  SSH key and the backup passphrase. Keep these in a sealed envelope with the
  adviser, not in a group chat.
- **This guide:** update anything that changed and pass it on.

---

More detail for the technical contact: the main [readme](../readme.md) and
the [stress-test report](stress-test-report.md).
