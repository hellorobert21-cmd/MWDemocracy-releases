# Software updates

How a school that runs its own MWDemocracy server gets new versions, and how
the vendor publishes them. Nothing is ever pushed into a school's server: the
server *checks* for a signed release, officers *approve* it, and a script on
the server *installs* it, with a backup first and an automatic rollback.

```
vendor                         school server
------                         -------------
sign release  ──► MWDemocracy-releases/latest.txt ◄── checks every 6 h (signature must match)
                                         │
                       Overview: "Update available 1.5.0"  ── officer presses Install
                                         │  (second admin approves, if two-officer approval is on;
                                         │   refused while any election is open or paused)
                                         ▼
                   deploy/update.sh (cron, every 5 min):
                   verify → backup → install → health check → done
                                                     └─ any failure → previous version restored
```

## Safety rules built in

| Rule | Why |
|---|---|
| Release files are signed with a **release key** (Ed25519), separate from the license key | Someone who takes over the GitHub account still can't ship an update servers will accept |
| The signature is checked by the version **already running** | A bad release can't vouch for itself |
| Images must be pinned by **digest** (`name@sha256:…`); source builds use the exact signed **commit** | What was signed is exactly what gets installed |
| Never while an election is **open** or voting is **paused** | An update can't interrupt voting |
| **Backup** before every install; **rollback** if it doesn't start, fails the health check, reports the wrong version or fails the web-file check | A failed update costs minutes, not data |
| Database changes only **add** tables/columns; older versions start on a newer database | Rollback works after migrations ran |
| The check sends **no school data** (a plain download; the version in the User-Agent) | Data Privacy Act; schools can set `UPDATE_URL=off` |

## For the vendor: one-time setup

```bash
# Generate the release key (keep it OFFLINE with the license key, on a USB drive, plus a backup).
mwdemocracy release keygen --private-key-out ~/mwd-keys/release.key
# Put the printed public key in backend/release_pubkey.txt, commit, and release that version.
```

Servers built **before** `release_pubkey.txt` was filled in don't check for
updates (the Overview card is hidden). Schools on those versions update once by
hand (`git pull && docker compose up -d --build`); after that, updates are automatic.

## For the vendor: publishing a release

1. Bump the version in `Cargo.toml`, commit, tag (`git tag v1.5.0`) and push.
   Make sure CI is green.
2. *(Optional)* build and push an image, and note its digest:
   ```bash
   docker build -t ghcr.io/<you>/mwdemocracy:1.5.0 --build-arg GIT_COMMIT=$(git rev-parse --short=12 HEAD) .
   docker push ghcr.io/<you>/mwdemocracy:1.5.0     # prints: digest: sha256:…
   ```
   Without an image, schools build the signed commit themselves (slower, no registry needed).
3. Sign the release file:
   ```bash
   mwdemocracy release sign --private-key ~/mwd-keys/release.key \
     --commit $(git rev-parse HEAD) \
     --image ghcr.io/<you>/mwdemocracy@sha256:<digest> \
     --kit-sha256 <kit fingerprint from the release run> \
     --notes "Faster results page; 2FA codes work once." \
     --notes-url https://github.com/<you>/MWDemocracy/releases/tag/v1.5.0 \
     --out latest.txt                                        # add --security for security fixes
   mwdemocracy release verify latest.txt                   # double-check
   # --image is optional (without it, schools build the signed commit);
   # --kit <zip> instead of --kit-sha256 computes the fingerprint from the file.
   ```
4. Commit `latest.txt` to the public `MWDemocracy-releases` repository and push
   (see [distribution.md](distribution.md)). Servers see it within 6 hours
   (officers can press **Check now**).

**Security fixes:** sign with `--security` (the card turns red), and also
email every school on your license list; don't rely on the dashboard alone.

**If the release key leaks:** generate a new one, put the new public key in a
release signed with the *old* key (so servers can still accept it), then stop
using the old key.

**Paid updates later:** keep the feed public but push images to a private
registry, and give each school a registry token tied to its license. An expired
license then keeps working but stops receiving new images. Keep security fixes
available to everyone.

## For the school's technical contact

- `deploy/install.sh` schedules `deploy/update.sh` every 5 minutes. It does
  nothing unless officers approved an update. To add it by hand:
  ```bash
  (crontab -l; echo "*/5 * * * * cd $(pwd) && ./deploy/update.sh >> backups/update.log 2>&1") | crontab -
  ```
- `./deploy/update.sh --status` shows what is waiting; `backups/update.log` has
  the history. The Overview card shows the last result.
- **Offline school:** download `latest.txt` on another computer, copy it over
  and run `./deploy/update.sh --file latest.txt` (with the image digest variant,
  the image must also be loaded with `docker load`).
- **Manual rollback:** `docker tag mwdemocracy:rollback mwdemocracy:latest && docker compose up -d app`.
