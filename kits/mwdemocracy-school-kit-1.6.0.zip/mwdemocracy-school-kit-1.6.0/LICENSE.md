# MWDemocracy Software License

Copyright © 2026 Robert Andre M. Arpilleda. All rights reserved.

MWDemocracy (the "Software") is proprietary software. It is licensed, not sold.
This license explains what you may and may not do with it.

## 1. Definitions

- **Author**: Robert Andre M. Arpilleda, the copyright holder.
- **Licensee**: the school, division office or organization named in a valid
  License Key issued by the Author.
- **License Key**: a license file (`license.txt`) digitally signed by the Author
  that names the Licensee and any limits, such as a maximum number of voters or
  an expiry date.
- **Installation**: one running copy of the Software, with its database, serving
  one Licensee.

## 2. Founding school license

**Moonwalk National High School (MWNHS)** is granted a perpetual, royalty-free,
non-transferable license to install, use and customize the Software for its own
student elections, with no limit on the number of voters. This grant does not
let MWNHS sublicense, sell or give the Software to other schools.

## 3. License grant to other Licensees

With a valid License Key, the Licensee may:

1. install and run the Software on servers it controls or rents, for its own
   elections, within the limits stated in its License Key;
2. change the Software's branding (school name, logos, colors, themes and text)
   through the built-in branding settings or theme files;
3. make backup copies of the Software and its data.

Without a valid License Key, the Software runs as an **evaluation copy** limited
to 50 voters. Evaluation copies may be used only to try the Software. They may
not be used for official elections.

## 4. Restrictions

Unless the Author gives written permission, the Licensee may not:

1. copy, distribute, sell, rent, lease or sublicense the Software, or provide it
   to third parties as a hosted service;
2. remove, bypass or tamper with the license check, or create or alter License
   Keys;
3. remove or hide the "Powered by MWDemocracy" notice or this license;
4. use the Software for elections of another organization that does not hold its
   own License Key;
5. reverse engineer, decompile or disassemble the Software, or try to obtain its
   source code, except to the extent applicable law (such as the Intellectual
   Property Code of the Philippines) expressly permits despite this restriction;
6. share the Software's install kit, container image or registry access with
   anyone other than the Licensee's own technical staff.

The Software is delivered as a compiled container image and an install kit. The
source code is not part of the license; the Author may offer a supervised source
code review under a separate written agreement.

## 5. Data and privacy

The Licensee owns all election data stored in its Installation (voter lists,
ballots and audit logs) and is the **personal information controller** for that
data under the Data Privacy Act of 2012 (RA 10173). The Software does not send
election data to the Author or to any third party. The Licensee is responsible
for securing its server, keeping backups, and following DepEd and school data
privacy policies.

## 6. Third-party components

The Software includes open-source libraries (for example Rust crates and the
PostgreSQL database), each under its own license, such as MIT or Apache-2.0.
Nothing in this license limits your rights under those licenses for those
components.

## 7. Updates and support

Updates, support and License Key renewals are provided at the Author's
discretion or under a separate agreement.

## 8. No warranty

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. The Licensee is responsible for
how elections are run, including deciding on and certifying results under its
own election rules.

## 9. Limitation of liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE AUTHOR IS NOT LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY ARISING FROM THE SOFTWARE OR ITS USE.

## 10. Termination

This license ends automatically if the Licensee breaks its terms. When it ends,
the Licensee must stop using the Software. The Licensee keeps ownership of its
election data and may export it.

## 11. Governing law

This license is governed by the laws of the Republic of the Philippines.

---

For licensing inquiries, contact the Author.
